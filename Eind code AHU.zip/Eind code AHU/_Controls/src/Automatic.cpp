#include "Automatic.h"

Automatic::Automatic()
{
	Initialize();
}

Automatic::~Automatic()
{}

void Automatic::Initialize()
{

	//mController = ControlBuilder::GetController();
}

void Automatic::Update()
{
	std::cout << "updating" << std::endl;
}
